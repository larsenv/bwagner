import java.util.*; // for Scanner from Java 1.5, 1.6
import java.io.*;   // for file input
import static java.lang.System.*;

public class DoubleT
{
	public static void main(String[] args) throws IOException
	{
		int i,a,b,c,d,x,y,z;
		
		String s,s1;
		String[] t;
	
		//Scanner input = new Scanner(new File("similar.dat"));
		PrintWriter output = new PrintWriter(new File("doublet.out"));		
			
	out.println("TTTTTTTTTTTTTTT");
	out.println("T     TTT     T");
	out.println("T     TTT     T");
	out.println("      TTT      ");
	out.println("   TTTTTTTTT   ");
	out.println("   T  TTT  T   ");
	out.println("      TTT      ");
	out.println("      TTT      ");
	out.println("      TTT      ");
	out.println("      TTT      ");
	
	
	output.println("TTTTTTTTTTTTTTT");
	output.println("T     TTT     T");
	output.println("T     TTT     T");
	output.println("      TTT      ");
	output.println("   TTTTTTTTT   ");
	output.println("   T  TTT  T   ");
	output.println("      TTT      ");
	output.println("      TTT      ");
	output.println("      TTT      ");
	output.println("      TTT      ");
		
	//input.close();
	output.close();	
	}
}
