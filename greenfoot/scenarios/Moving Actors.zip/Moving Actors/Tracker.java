import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.*;
import java.awt.image.*;

/**
 * Write a description of class BoxBug here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Tracker extends Actor
{
     private GreenfootImage background;
     private int prevX = -1;
     private int prevY = -1;
     private boolean startTracks = false;
     
    public void leaveTrack()
    {
        background = getWorld().getBackground();
        BufferedImage img = background.getAwtImage();
        Graphics2D g2 = (Graphics2D)img.getGraphics();
        g2.setStroke(new BasicStroke(1));
        g2.setColor(Color.black);
        if(startTracks == false)
        {
            prevX = getX();
            prevY = getY();
            startTracks = true;
        }
        else
        {
            g2.drawLine(prevX, prevY, getX(), getY());
            prevX = getX();
            prevY = getY();
        }
       
    }
     
    
    public void leaveTrack(Color color, int thickness)
    {
        background = getWorld().getBackground();
        background.setColor(color);
        BufferedImage img = background.getAwtImage();
        Graphics2D g2 = (Graphics2D)img.getGraphics();
        g2.setStroke(new BasicStroke(thickness));
        g2.setColor(color);
        if(startTracks == false)
        {
            prevX = getX();
            prevY = getY();
            startTracks = true;
        }
        else
        {
            g2.drawLine(prevX, prevY, getX(), getY());
            prevX = getX();
            prevY = getY();
        }
       
    }
}
