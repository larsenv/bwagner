import greenfoot.*;

/**
 * Write a description of class Ball1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Ball1 extends Actor
{
    public void act() 
    {
        move(3);
    }    
}
