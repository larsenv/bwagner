import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.awt.*;   // Color

/**
 * Write a description of class CircleBug here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CircleBug extends Tracker
{
    public void act() 
    {

        
    }    
}

