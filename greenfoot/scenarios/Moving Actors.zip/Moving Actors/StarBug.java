import greenfoot.*;
import java.awt.*;   // Color

/**
 * Write a description of class StarBug here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class StarBug extends Tracker
{
    
    public void act() 
    {
        
        
        
        
    }    
}
